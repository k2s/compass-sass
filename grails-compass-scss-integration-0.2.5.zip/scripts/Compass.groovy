includeTargets << grailsScript("Init")

target(compass: 'Invokes arbitrary compass commands') {
}

setDefaultTarget(compass)
